package com.tiremgmt.tiremgmtcommon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiremgmtCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
