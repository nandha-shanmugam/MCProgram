package com.tiremgmt.tiremgmtcommon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiremgmtCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiremgmtCommonApplication.class, args);
	}

}
