package com.tiremgmt.membersvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MembersvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MembersvcApplication.class, args);
	}

}
