package com.tiremgmt.membersvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MembersvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
