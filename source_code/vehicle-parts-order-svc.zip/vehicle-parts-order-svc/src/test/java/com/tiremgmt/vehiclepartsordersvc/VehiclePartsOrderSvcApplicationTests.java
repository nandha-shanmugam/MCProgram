package com.tiremgmt.vehiclepartsordersvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiclePartsOrderSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
