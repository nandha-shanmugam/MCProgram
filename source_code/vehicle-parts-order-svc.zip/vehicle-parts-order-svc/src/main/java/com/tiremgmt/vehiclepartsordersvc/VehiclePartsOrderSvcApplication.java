package com.tiremgmt.vehiclepartsordersvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehiclePartsOrderSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehiclePartsOrderSvcApplication.class, args);
	}

}
